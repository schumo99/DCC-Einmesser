#ifndef Speed_Measure_h
#define Speed_Measure_h

#include <Arduino.h>

#define LS_MESS_INTERVALL          500 //Messinterval in Millisekunden
#define MESS_IMPULSE               30  //Impulse pro Messintervall
#define DURCHMESSER_ABNAHME        80  //in Zentel-Millimeter 
#define LOECHER_PRO_UMLAUF         20  //Lochscheibe
#define SCALE                      87  //Massstab
#define FILTER                     200 //Microsekunden Unterdrueckung doppelter Impulse
#define MAX_INDEX                  15  //Messwertspeicher der letzten Geschwindigkeiten
#define LICHTSCHRANKE_INPUT        15   //A8 - A15  
#define ERGEBNIS_INDEX             4/5-1  //fuer Ausgabe Ergebnis

#define SECOND_SERIAL

class Speed_Measure {
  public:
    // static void begin();
    static void set(byte);
    static void set(byte, int, int, int, int);
    static void messen();
    static void begin();
    static void loop();
  private:
    static void bubblesort(int [], int);
    static void print_kommazahl(int);
};

#endif
