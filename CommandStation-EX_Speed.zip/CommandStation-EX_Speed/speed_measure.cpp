#include "speed_measure.h"
#include <util/atomic.h>
#include "DCC.h"
#include "DCCWaveform.h"
#include "StringFormatter.h"
#include "DCCEXParser.h"

unsigned long count;
volatile unsigned long impulse;
volatile unsigned long old_t;
byte v_geomean_index;
int v_geomean[MAX_INDEX];
int v_hist_alt;
int scale;
byte FILTERSTAERKE[] = {MAX_INDEX / 2 + 1, MAX_INDEX * 2 / 3, MAX_INDEX};
int speed_measurement_on_off = 0;
int filter_staerke = 0;
int mess_impulse;
int ls_messinterval;
byte anpassung = 1;
float durchmesser;
int input_pin;
int last_v;

void Speed_Measure::set(byte _speed_measurement_on_off) {
  Speed_Measure::set(_speed_measurement_on_off, 0, 0, 0, 0);
}

void Speed_Measure::set(byte _speed_measurement_on_off, int _filterstaerke, int _input_pin, int _scale, int _durchmesser) {
#if !defined(ARDUINO_AVR_MEGA2560)
  Serial.println("Only Mega2560 supported!");
  return;
#endif
  speed_measurement_on_off = _speed_measurement_on_off;
  if (speed_measurement_on_off) {
    if (_filterstaerke != 0) {
      if (_filterstaerke < 1 || _filterstaerke > 3) _filterstaerke = 2;
      filter_staerke = _filterstaerke;
      filter_staerke--;
    }
    if (_input_pin != 0) {
      if (_input_pin < 8 && _input_pin > 15) _input_pin = LICHTSCHRANKE_INPUT;
      input_pin = _input_pin;
    }
    if (_scale != 0) {
      if (_scale < 0) _scale = SCALE;
      scale = _scale;
    }
    if (_durchmesser != 0) {
      if (_durchmesser < 0 || _durchmesser > 1000) _durchmesser = DURCHMESSER_ABNAHME;
      durchmesser = _durchmesser;
    }

    if (filter_staerke == 0) filter_staerke = 1;
    if  (input_pin == 0) input_pin = LICHTSCHRANKE_INPUT;
    if (scale == 0) scale = SCALE;
    if (durchmesser == 0) durchmesser = DURCHMESSER_ABNAHME;

    ls_messinterval = LS_MESS_INTERVALL / 2 * (filter_staerke + 1);
    mess_impulse = MESS_IMPULSE / 2 * (filter_staerke + 1);
    PCICR |= (1 << PCIE2);
    switch (input_pin) {
      case 8:
        PCMSK2 |= (1 << PCINT16);
        break;
      case 9:
        PCMSK2 |= (1 << PCINT17);
        break;
      case 10:
        PCMSK2 |= (1 << PCINT18);
        break;
      case 11:
        PCMSK2 |= (1 << PCINT19);
        break;
      case 12:
        PCMSK2 |= (1 << PCINT20);
        break;
      case 13:
        PCMSK2 |= (1 << PCINT21);
        break;
      case 14:
        PCMSK2 |= (1 << PCINT22);
        break;
      case 15:
        PCMSK2 |= (1 << PCINT23);
        break;
    }
    PCMSK2 |= (1 << PCINT16);
    v_geomean_index = 0;
    for (int i = 0; i < MAX_INDEX; i++) {
      v_geomean[i] = 0;
    }
  } else {
    PCICR &= ~(1 << PCIE2);
  }
}

ISR (PCINT2_vect) {
  unsigned long t = micros();
  unsigned long t_diff = t - old_t;
  if (t_diff > FILTER) {
    old_t = t;
    impulse++;
  }
}


void Speed_Measure::begin() {
#if defined(SECOND_SERIAL)
  Serial1.begin(57600);
#endif
}

void Speed_Measure::loop() {
  if (!speed_measurement_on_off) return;
  Speed_Measure::messen();
}

void Speed_Measure::messen() {
  static unsigned long lastMicros = 0;
  unsigned long ms = micros();

  if ((ms - lastMicros) / 1000 >= ls_messinterval * anpassung || impulse >  mess_impulse * anpassung)
  {
    ATOMIC_BLOCK (ATOMIC_RESTORESTATE)
    {
      count = impulse;
      impulse = 0;
    }
    ms = micros();
    anpassung = 1;
    if (count < 10) anpassung = 2;
    if (count < 5) anpassung = 4;
    float rpm;
    float v;
    rpm = 1.0 * count * 1000000 * 60 / (ms - lastMicros) / LOECHER_PRO_UMLAUF;
    v = rpm * durchmesser / 10 * PI; // mm/min
    v = v * scale * 60 / 1000000; //km/h
    v_geomean[v_geomean_index] = int(v * 10); //in Zehntel-km/h
    int akt_v = int(v_geomean[v_geomean_index] + last_v) / 2;
    Serial.print("<g");
    Serial.print(akt_v);
    Serial.print(">");
#if defined(SECOND_SERIAL)
    Serial1.print("<g");
    Serial1.print(akt_v);
    Serial1.print(">");
#endif
    last_v = (akt_v + (v_geomean[v_geomean_index]) * 2) / 3;
    //Speed_Measure::print_kommazahl(v_geomean[v_geomean_index]);
    v_geomean_index++;
    lastMicros = ms;
    if (v_geomean_index >= FILTERSTAERKE[filter_staerke]) {
      v_geomean_index = 0;
      Speed_Measure::bubblesort(v_geomean, FILTERSTAERKE[filter_staerke]);
      Serial.print("  <G ");
      Serial.print(int((v_geomean[FILTERSTAERKE[filter_staerke] * ERGEBNIS_INDEX])));
      Serial.print(">");
#if defined(SECOND_SERIAL)
      Serial1.print("  <G ");
      Serial1.print(int((v_geomean[FILTERSTAERKE[filter_staerke] * ERGEBNIS_INDEX])));
      Serial1.println(">");
#endif
      /*
        long sum = 0;
        byte anzahl = 0;
        for (int i = FILTERSTAERKE[filter_staerke] * 2 / 5; i < FILTERSTAERKE[filter_staerke] * ERGEBNIS_INDEX + 1; i++) {
        sum += v_geomean[i];
        anzahl++;
        }
      */
      long abw;
      if (v_geomean[FILTERSTAERKE[filter_staerke] * ERGEBNIS_INDEX] != 0) {
        abw = 1000L * (v_geomean[FILTERSTAERKE[filter_staerke] * ERGEBNIS_INDEX] - v_hist_alt) / v_geomean[FILTERSTAERKE[filter_staerke] * ERGEBNIS_INDEX];
        if (abw < 0) abw = -abw;
        Serial.print(" (");
        Speed_Measure::print_kommazahl(abw);
        Serial.print("%)");
      }
      Serial.println(" ");
      v_hist_alt = v_geomean[FILTERSTAERKE[filter_staerke] * ERGEBNIS_INDEX];
    }
  }
}

void Speed_Measure::bubblesort(int a[], int size) {
  for (int i = 0; i < (size - 1); i++) {
    for (int o = 0; o < (size - (i + 1)); o++) {
      if (a[o] > a[o + 1]) {
        int t = a[o];
        a[o] = a[o + 1];
        a[o + 1] = t;
      }
    }
  }
}

void Speed_Measure::print_kommazahl(int print_v) {
  char sFrame[7] = {'\0'}; // Array to store serial string
  sprintf(sFrame, " %3d.%01d", print_v / 10, print_v % 10);
  Serial.print(sFrame);
}
